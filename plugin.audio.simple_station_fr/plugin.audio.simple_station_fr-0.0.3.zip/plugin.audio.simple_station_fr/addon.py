from simple_station import SimpleStation
from simple_station import FIP
from simple_station import FranceInter
from simple_station import FranceCulture
from simple_station import FranceMusique
from simple_station import FranceInfo

if __name__ == '__main__':
  SimpleStation().run()
